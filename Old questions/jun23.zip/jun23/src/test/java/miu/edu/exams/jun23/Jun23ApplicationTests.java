package miu.edu.exams.jun23;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jun23ApplicationTests {

	@Test
	void contextLoads() {
	}

}
